from setuptools import setup
setup(
    name='chisco_valida_rfc',
    version='0.0.1',
    packages=['chisco_valida_rfc'],
    install_requires=[
            'bs4',
            'requests',
    ],)
